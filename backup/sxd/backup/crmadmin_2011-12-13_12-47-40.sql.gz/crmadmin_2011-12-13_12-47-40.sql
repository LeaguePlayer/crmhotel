#SXD20|20008|50140|50303|2011.12.13 12:47:40|crmadmin|0|10|7|
#TA client_hotel`0`0|clients`0`0|hotel_order`0`0|hotels`0`0|logs`0`0|phones`0`0|tbl_profiles`2`16384|tbl_profiles_fields``|tbl_users`5`16384|ticks`0`0
#EOH

#	TC`client_hotel`utf8_general_ci	;
CREATE TABLE `client_hotel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `date_stay_begin` datetime NOT NULL,
  `date_stay_finish` datetime NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`clients`utf8_general_ci	;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`hotel_order`utf8_general_ci	;
CREATE TABLE `hotel_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_hotel` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `date_stay_begin` datetime NOT NULL,
  `date_stay_finish` datetime NOT NULL,
  `price_per_day` int(10) unsigned NOT NULL,
  `places` int(10) unsigned NOT NULL,
  `id_invite` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`hotels`utf8_general_ci	;
CREATE TABLE `hotels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `id_cat` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  `default_type` int(2) NOT NULL,
  `dirty` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`logs`utf8_general_ci	;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_client` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `id_invite` int(11) NOT NULL,
  `price_per_day` int(11) NOT NULL,
  `got_money` int(11) NOT NULL,
  `date_stay_begin` datetime NOT NULL,
  `date_stay_finish` datetime NOT NULL,
  `got_money_docs` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`phones`utf8_general_ci	;
CREATE TABLE `phones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_client` int(11) NOT NULL,
  `phone` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`tbl_profiles`utf8_general_ci	;
CREATE TABLE `tbl_profiles` (
  `user_id` int(11) NOT NULL,
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`tbl_profiles`utf8_general_ci	;
INSERT INTO `tbl_profiles` VALUES 
(1,'Admin','Administrator','0000-00-00'),
(2,'Demo','Demo','0000-00-00')	;
#	TC`tbl_profiles_fields`utf8_general_ci	;
CREATE TABLE `tbl_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TC`tbl_users`utf8_general_ci	;
CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `lastvisit` int(10) NOT NULL DEFAULT '0',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`tbl_users`utf8_general_ci	;
INSERT INTO `tbl_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','webmaster@example.com','9a24eff8c15a6a141ece27eb6947da0f',1261146094,1323767958,1,1),
(2,'driver','e10adc3949ba59abbe56e057f20f883e','demo@example.com','099f825543f7850cc038b90aaff39fac',1261146096,1323168854,3,1),
(3,'office','e10adc3949ba59abbe56e057f20f883e','demo2@example.com','099f825543f7850cc038b90aaff39fac',1261146096,1323168854,5,1),
(4,'driver2','e10adc3949ba59abbe56e057f20f883e','demo3@example.com','099f825543f7850cc038b90aaff39fac',1261146096,1323168854,3,1),
(5,'manager','e10adc3949ba59abbe56e057f20f883e','demo4@example.com','099f825543f7850cc038b90aaff39fac',1261146096,1323168854,2,1)	;
#	TC`ticks`utf8_general_ci	;
CREATE TABLE `ticks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_clienthotel` int(11) NOT NULL,
  `date_period_begin` datetime NOT NULL,
  `date_period_finish` datetime NOT NULL,
  `status` int(2) NOT NULL,
  `finish_sum` int(11) NOT NULL,
  `note` text NOT NULL,
  `id_informer` int(4) NOT NULL,
  `sum_for_days` int(11) NOT NULL,
  `sum_for_doc` int(11) NOT NULL,
  `date_public` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
